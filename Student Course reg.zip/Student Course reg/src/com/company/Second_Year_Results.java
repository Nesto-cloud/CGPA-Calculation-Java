package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Second_Year_Results {
//    static String grade =" ";
    static  int mypoints = 0;
//    static int Course_Score = 0;
    static int course_no = 0;
    static int[] grade_point2 =new int[11];
    public static void second_year_results(){

        First_Year_results year1_mtds = new First_Year_results();
        System.out.println(" Year one result ");
        System.out.println("                                  ");
        System.out.println(".....Enter your score for the courses as they appear......");
        System.out.println("S/N   Course Code   Course Title            Unit Load   Score   ");

        System.out.print("1    MTH 211       Advanced math            3          ");
        mypoints = year1_mtds.determine_grade();
        grade_point2[course_no] = mypoints;
        course_no++;
        System.out.print("2    MTH 212       Advanced math 2          2          ");
        mypoints = year1_mtds.determine_grade();
        grade_point2[course_no] = mypoints;
        course_no++;
        System.out.print("3    MTH 222       Advanced math            4          ");
        mypoints = year1_mtds.determine_grade();
        grade_point2[course_no] = mypoints;
        course_no++;
        System.out.print("4    Phy 211       Advanced physics 1       1          ");
        mypoints = year1_mtds.determine_grade();
        grade_point2[course_no] = mypoints;
        course_no++;
        System.out.print("5    Phy 212       Advanced physics 2       3          ");
        mypoints = year1_mtds.determine_grade();
        grade_point2[course_no] = mypoints;
        course_no++;
        System.out.print("6    Phy 222       Advanced physics 3       4          ");
        mypoints = year1_mtds.determine_grade();
        System.out.println(mypoints);
        grade_point2[course_no] = mypoints;
        course_no++;
        System.out.print("7    chm 211       Advanced chem 1          3          ");
        mypoints = year1_mtds.determine_grade();
        grade_point2[course_no] = mypoints;
        course_no++;
        System.out.print("8    chm 222       Advanced chem 2          3          ");
        mypoints = year1_mtds.determine_grade();
        grade_point2[course_no] = mypoints;
        course_no++;
        System.out.print("9    chm 212       Advanced chemistry 3     5          ");
        mypoints = year1_mtds.determine_grade();
        grade_point2[course_no] = mypoints;
        course_no++;
        System.out.print("10   chm 201       Advanced chemistry 4     3          ");
        mypoints = year1_mtds.determine_grade();
        grade_point2[course_no] = mypoints;
        course_no++;
        System.out.println(Arrays.toString(grade_point2));


        int[] unitLoad = {3, 2, 4, 1, 3, 4, 3, 3, 5, 3};
        int Total_unit_load = 0;
        float Total_grade_point = 0;
        for (int j=0; j<10; j++){
            Total_unit_load = Total_unit_load + unitLoad[j];
            Total_grade_point = (unitLoad[j]*grade_point2[j]) + Total_grade_point;
        }
        System.out.println("Total Grade point: "+ Total_grade_point);
        System.out.println("Total Unit Load: "+ Total_unit_load);

        float GPA = Total_grade_point/Total_unit_load;
        System.out.print("GPA: ");
        System.out.printf("%.2f",GPA);
        System.out.println("               ");
        year1_mtds.determine_class(GPA);

    }
}
