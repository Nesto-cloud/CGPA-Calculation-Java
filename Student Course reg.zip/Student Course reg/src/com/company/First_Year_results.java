package com.company;

import java.util.Arrays;
import java.util.Scanner;


public class First_Year_results {
    static String grade =" ";
    static int points = 0;
    static int Course_Score = 0;
    static int course_no = 0;
    static int[] grade_point =new int[11];


    public static void first_year_results(){

        System.out.println(" Year one result ");
        System.out.println("                                  ");
        System.out.println(".....Enter your score for the courses as they appear......");
        System.out.println("S/N   Course Code   Course Title            Unit Load   Score   ");

        System.out.print("1    MTH 111       Introductory math         3          ");
        Scanner score = new Scanner(System.in);
        points = determine_grade();
        grade_point[course_no] = points;
        course_no++;
        System.out.print("2    MTH 112       Introductory math 2       2          ");
        points = determine_grade();
        grade_point[course_no] = points;
        course_no++;
        System.out.print("3    MTH 122       Intro math                4          ");
        points = determine_grade();
        grade_point[course_no] = points;
        course_no++;
        System.out.print("4    Phy 111       introductory physics 1    1          ");
        points = determine_grade();
        grade_point[course_no] = points;
        course_no++;
        System.out.print("5    Phy 112       introductory physics 2    3          ");
        points = determine_grade();
        grade_point[course_no] = points;
        course_no++;
        System.out.print("6    Phy 122       introductory physics 3    4          ");
        points = determine_grade();
        grade_point[course_no] = points;
        course_no++;
        System.out.print("7    chm 111       introductory chem 1       3          ");
        points = determine_grade();
        grade_point[course_no] = points;
        course_no++;
        System.out.print("8    chm 122       introductory chem 2       3          ");
        points = determine_grade();
        grade_point[course_no] = points;
        course_no++;
        System.out.print("9    chm 112       introductory chemistry 3  5          ");
        points = determine_grade();
        grade_point[course_no] = points;
        course_no++;
        System.out.print("10   chm 101       introductory chemistry 4  3          ");
        points = determine_grade();
        grade_point[course_no] = points;
        course_no++;
        System.out.println(Arrays.toString(grade_point));


        int[] unitLoad = {3, 2, 4, 1, 3, 4, 3, 3, 5, 3};
        int Total_unit_load = 0;
        float Total_grade_point = 0;
        for (int j=0; j<10; j++){
            Total_unit_load = Total_unit_load + unitLoad[j];
            Total_grade_point = (unitLoad[j]*grade_point[j]) + Total_grade_point;
        }
        System.out.println("Total Grade point: "+ Total_grade_point);
        System.out.println("Total Unit Load: "+ Total_unit_load);

        float GPA = Total_grade_point/Total_unit_load;
        System.out.print("GPA: ");
        System.out.printf("%.2f",GPA);
        System.out.println("               ");
        determine_class(GPA);

    }
    public static int determine_grade(){

        Scanner score = new Scanner(System.in);
        Course_Score = score.nextInt();
        if (Course_Score< 45){
            grade = "F";
            points= 0;
        }
        else if (Course_Score < 50  ) {
            grade = "D";
            points = 2;
        }
        else if (Course_Score < 60 ) {
            grade = "C";
            points = 3;
        }
        else if (Course_Score < 70 ) {
            grade = "B";
            points = 4;
        }
        else {
            grade = "A";
            points = 5;
        }
        System.out.println("grade: " + grade);
        return points;
    }
    public static void determine_class(float grossPoint){
        if (grossPoint< 1.5){
            System.out.println("You Got a pass");
        }
        else if (grossPoint < 2.4 ){
            System.out.println("you got a Third class Honours");
        }
        else if (grossPoint < 3.5){
            System.out.println("you got a Second Class Honours Lower division");

        }
        else if (grossPoint < 4.5){
            System.out.println("you got a Second Class Honours Upper division");

        }
        else if (grossPoint >= 4.5){
            System.out.println("you got a First Class Honours ");
        }
        else{
            System.out.println("Sorry you could not pass");
        }


    }
}
