package com.company;

import java.util.Scanner;
import java.util.Arrays;

public class Main {




    public static void main(String[] args) {

        First_Year_results Year1 = new First_Year_results();
        Second_Year_Results Year2 = new Second_Year_Results();
        Year2.second_year_results();
        Year1.first_year_results();


    }





}
